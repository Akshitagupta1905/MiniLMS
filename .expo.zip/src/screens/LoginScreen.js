import { View, Text, TextInput, Button } from "react-native";
import { useState } from "react";

export default function LoginScreen() {

const [email, setEmail] = useState("");
const [password, setPassword] = useState("");

return (

<View style={{padding:20}}>

<Text style={{fontSize:22}}>Login</Text>

<TextInput
placeholder="Email"
value={email}
onChangeText={setEmail}
style={{borderWidth:1, marginTop:10, padding:8}}
/>

<TextInput
placeholder="Password"
value={password}
secureTextEntry
onChangeText={setPassword}
style={{borderWidth:1, marginTop:10, padding:8}}
/>

<Button title="Login" />

</View>

);

}