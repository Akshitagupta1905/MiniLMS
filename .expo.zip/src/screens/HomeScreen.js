import { View, Text, FlatList, Image } from "react-native";
import { useEffect, useState } from "react";
import { getCourses } from "../services/api";

export default function HomeScreen() {
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    const data = await getCourses();
    setCourses(data);
  };

  const renderItem = ({ item }) => {
    return (
      <View
        style={{
          borderWidth: 1,
          margin: 10,
          padding: 10,
          borderRadius: 10,
        }}
      >
        <Image
          source={{ uri: item.thumbnail || item.images?.[0] }}
          style={{ width: "100%", height: 150 }}
        />

        <Text style={{ fontSize: 18, marginTop: 10 }}>{item.title}</Text>

        <Text>{item.description}</Text>
      </View>
    );
  };

  return (
    <View>
      <Text style={{ fontSize: 22, textAlign: "center", marginTop: 40 }}>
        Courses
      </Text>

      <FlatList
        data={courses}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
}