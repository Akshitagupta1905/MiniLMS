import { View, Text, TextInput, Button } from "react-native";
import { useState } from "react";
import api from "../src/services/api";

export default function Login() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {

    try {

      const response = await api.post("/api/v1/users/login", {
        email: email,
        password: password
      });

      console.log(response.data);

    } catch (error) {
      console.log("Login error", error);
    }

  };

  return (
    <View style={{padding:20}}>

      <Text style={{fontSize:20}}>Login</Text>

      <TextInput
        placeholder="Enter email"
        onChangeText={setEmail}
        style={{borderWidth:1,marginTop:10,padding:8}}
      />

      <TextInput
        placeholder="Enter password"
        secureTextEntry
        onChangeText={setPassword}
        style={{borderWidth:1,marginTop:10,padding:8}}
      />

      <Button title="Login" onPress={handleLogin} />

    </View>
  );
}