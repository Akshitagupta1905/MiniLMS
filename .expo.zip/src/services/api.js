export const getCourses = async () => {
  try {
    const response = await fetch(
      "https://api.freeapi.app/api/v1/public/randomproducts"
    );

    const result = await response.json();

    console.log("API DATA:", result);

    return result.data.data;   // ⭐ यही important है
  } catch (error) {
    console.log("API Error", error);
  }
};