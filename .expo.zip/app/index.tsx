import { View, Text } from "react-native";

export default function Home() {
  return (
    <View>
      <Text>Mini LMS Home Screen</Text>
    </View>
  );
}