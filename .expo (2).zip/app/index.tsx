import { useEffect } from "react";
import { View, Text, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { useAuthStore } from "../store/authStore";
import { COLORS } from "../constants";

export default function SplashScreen() {
  const { isLoggedIn, isLoading } = useAuthStore();

  useEffect(() => {
    const timer = setTimeout(() => {
      if (!isLoading) {
        if (isLoggedIn) {
          router.replace("/(tabs)" as any);
        } else {
          router.replace("/(auth)/login" as any);
        }
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [isLoading, isLoggedIn]);

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: COLORS.primary,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Text style={{ fontSize: 60, marginBottom: 16 }}>📚</Text>
      <Text
        style={{
          fontSize: 32,
          fontWeight: "bold",
          color: COLORS.white,
          marginBottom: 8,
        }}
      >
        MiniLMS
      </Text>
      <Text
        style={{
          fontSize: 16,
          color: COLORS.white + "CC",
          marginBottom: 40,
        }}
      >
        Seekhte raho, badhte raho
      </Text>
      <ActivityIndicator size="large" color={COLORS.white} />
    </View>
  );
}