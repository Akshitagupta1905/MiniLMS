import {
  View,
  Text,
  TouchableOpacity,
  Image,
  Alert,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { useAuthStore } from "../../store/authStore";
import { useCourseStore } from "../../store/courseStore";
import { COLORS } from "../../constants";
import { router } from "expo-router";
import * as ImagePicker from "expo-image-picker";
import { useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { STORAGE_KEYS } from "../../constants";

export default function ProfileScreen() {
  const { user, logout, setUser } = useAuthStore();
  const { bookmarks, enrolledCourses } = useCourseStore();
  const [uploading, setUploading] = useState(false);
  const [localAvatar, setLocalAvatar] = useState<string | null>(null);

  const handleLogout = () => {
    Alert.alert("Logout", "Kya sach mein logout karna hai?", [
      { text: "Nahi", style: "cancel" },
      {
        text: "Haan",
        style: "destructive",
        onPress: async () => {
          await logout();
          router.replace("/(auth)/login" as any);
        },
      },
    ]);
  };

  const handleProfilePicture = () => {
    Alert.alert("Profile Picture", "Where do you want to take it from", [
      { text: "Cancel", style: "cancel" },
      { text: "📷 Camera", onPress: () => openCamera() },
      { text: "🖼️ Gallery", onPress: () => openGallery() },
    ]);
  };

  const openCamera = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission chahiye", "Camera use karne ki permission do");
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled) {
      saveProfilePicture(result.assets[0].uri);
    }
  };

  const openGallery = async () => {
    const permission =
      await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission chahiye", "Gallery access karne ki permission do");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled) {
      saveProfilePicture(result.assets[0].uri);
    }
  };

  const saveProfilePicture = async (uri: string) => {
    setUploading(true);
    try {
      // Local mein save karo
      await AsyncStorage.setItem("profile_picture", uri);
      setLocalAvatar(uri);
      Alert.alert("Success! 🎉", "Profile picture update ho gayi!");
    } catch (error) {
      Alert.alert("Error", "Picture save nahi hui");
    } finally {
      setUploading(false);
    }
  };

  // Avatar URL decide karo
  const avatarUri =
    localAvatar || user?.avatar?.url || null;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: COLORS.background }}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View
        style={{
          backgroundColor: COLORS.primary,
          paddingTop: 60,
          paddingBottom: 40,
          alignItems: "center",
        }}
      >
        {/* Avatar with Edit Button */}
        <TouchableOpacity
          onPress={handleProfilePicture}
          style={{ position: "relative", marginBottom: 12 }}
        >
          <View
            style={{
              width: 90,
              height: 90,
              borderRadius: 45,
              backgroundColor: COLORS.white,
              justifyContent: "center",
              alignItems: "center",
              overflow: "hidden",
              borderWidth: 3,
              borderColor: COLORS.white,
            }}
          >
            {uploading ? (
              <ActivityIndicator color={COLORS.primary} />
            ) : avatarUri ? (
              <Image
                source={{ uri: avatarUri }}
                style={{ width: 90, height: 90 }}
              />
            ) : (
              <Text style={{ fontSize: 40 }}>👤</Text>
            )}
          </View>

          {/* Edit Icon */}
          <View
            style={{
              position: "absolute",
              bottom: 0,
              right: 0,
              backgroundColor: COLORS.secondary,
              borderRadius: 12,
              width: 24,
              height: 24,
              justifyContent: "center",
              alignItems: "center",
              borderWidth: 2,
              borderColor: COLORS.white,
            }}
          >
            <Text style={{ fontSize: 12 }}>✏️</Text>
          </View>
        </TouchableOpacity>

        <Text
          style={{
            fontSize: 22,
            fontWeight: "bold",
            color: COLORS.white,
            marginBottom: 4,
          }}
        >
          {user?.username || "Student"}
        </Text>
        <Text style={{ fontSize: 14, color: COLORS.white + "CC" }}>
          {user?.email}
        </Text>
        <Text
          style={{
            fontSize: 12,
            color: COLORS.white + "99",
            marginTop: 4,
          }}
        >
          Tap to change profile
        </Text>
      </View>

      {/* Stats */}
      <View
        style={{
          flexDirection: "row",
          backgroundColor: COLORS.white,
          marginHorizontal: 24,
          marginTop: -20,
          borderRadius: 16,
          padding: 20,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.1,
          shadowRadius: 12,
          elevation: 5,
        }}
      >
        <View style={{ flex: 1, alignItems: "center" }}>
          <Text
            style={{
              fontSize: 28,
              fontWeight: "bold",
              color: COLORS.primary,
            }}
          >
            {enrolledCourses.length}
          </Text>
          <Text style={{ fontSize: 12, color: COLORS.gray, marginTop: 4 }}>
            Enrolled
          </Text>
        </View>
        <View style={{ width: 1, backgroundColor: COLORS.lightGray }} />
        <View style={{ flex: 1, alignItems: "center" }}>
          <Text
            style={{
              fontSize: 28,
              fontWeight: "bold",
              color: COLORS.secondary,
            }}
          >
            {bookmarks.length}
          </Text>
          <Text style={{ fontSize: 12, color: COLORS.gray, marginTop: 4 }}>
            Bookmarks
          </Text>
        </View>
      </View>

      {/* Menu Items */}
      <View
        style={{
          backgroundColor: COLORS.white,
          marginHorizontal: 24,
          marginTop: 24,
          borderRadius: 16,
          overflow: "hidden",
        }}
      >
        {[
          { icon: "📚", label: "Mere Courses" },
          { icon: "🔔", label: "Notifications" },
          { icon: "⚙️", label: "Settings" },
        ].map((item, index) => (
          <TouchableOpacity
            key={index}
            style={{
              flexDirection: "row",
              alignItems: "center",
              padding: 16,
              borderBottomWidth: index < 2 ? 1 : 0,
              borderBottomColor: COLORS.lightGray,
            }}
          >
            <Text style={{ fontSize: 20, marginRight: 12 }}>{item.icon}</Text>
            <Text
              style={{
                fontSize: 15,
                color: COLORS.black,
                fontWeight: "500",
                flex: 1,
              }}
            >
              {item.label}
            </Text>
            <Text style={{ color: COLORS.gray }}>›</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Logout Button */}
      <TouchableOpacity
        style={{
          backgroundColor: COLORS.error + "15",
          marginHorizontal: 24,
          marginTop: 24,
          marginBottom: 40,
          borderRadius: 16,
          padding: 16,
          alignItems: "center",
          flexDirection: "row",
          justifyContent: "center",
        }}
        onPress={handleLogout}
      >
        <Text style={{ fontSize: 20, marginRight: 8 }}>🚪</Text>
        <Text
          style={{
            color: COLORS.error,
            fontSize: 16,
            fontWeight: "bold",
          }}
        >
          Logout
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}